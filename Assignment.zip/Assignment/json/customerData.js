[ 
    {
        id: "100250",
        "name": "Shiva Sankaran",
        "email": "shivamadhurai@gmail.com",
        "phone": "9885552332",
        "location": "velachary"
    },
    {
        id: "100251",
        "name": "Ganapathy raman",
        "email": "ganapathyraman@gmail.com",
        "phone": "9775552666",
        "location": "East Tambaram"
    },
   {
        id: "100252",
        "name": "Shri Vignesh",
        "email": "shrivignesh@gmail.com",
        "phone": "9995552998",
        "location": "Selayur"
    }
]